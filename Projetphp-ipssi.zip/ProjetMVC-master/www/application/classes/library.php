<?php

$config['intercepting-filters'] = ['InfosUser'];