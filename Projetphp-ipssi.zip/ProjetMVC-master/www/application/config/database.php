<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=127.0.0.1;dbname=climbing;charset=utf8';
$config['password'] = '';
$config['user']     = 'root';